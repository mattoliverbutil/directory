﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dgvOutput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(dgvOutput))
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAddListing = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtCurrentDirectory = New System.Windows.Forms.TextBox()
        Me.btnNewDirectory = New System.Windows.Forms.Button()
        Me.ContactsDirectories = New System.Windows.Forms.ListBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(437, 249)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(179, 42)
        Me.btnRemove.TabIndex = 21
        Me.btnRemove.Text = "Delete Contact from the Current Directory"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAddListing
        '
        Me.btnAddListing.Location = New System.Drawing.Point(437, 200)
        Me.btnAddListing.Name = "btnAddListing"
        Me.btnAddListing.Size = New System.Drawing.Size(179, 43)
        Me.btnAddListing.TabIndex = 20
        Me.btnAddListing.Text = "Add Contact to the Current Directory"
        Me.btnAddListing.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(64, 36)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(335, 29)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Telephone/Mobile Directories"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(434, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Telephone/Mobile Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(434, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(434, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Current Directory "
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(437, 95)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(179, 20)
        Me.txtNumber.TabIndex = 15
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(437, 144)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(179, 20)
        Me.txtName.TabIndex = 14
        '
        'txtCurrentDirectory
        '
        Me.txtCurrentDirectory.Location = New System.Drawing.Point(437, 45)
        Me.txtCurrentDirectory.Name = "txtCurrentDirectory"
        Me.txtCurrentDirectory.ReadOnly = True
        Me.txtCurrentDirectory.Size = New System.Drawing.Size(179, 20)
        Me.txtCurrentDirectory.TabIndex = 13
        '
        'btnNewDirectory
        '
        Me.btnNewDirectory.Location = New System.Drawing.Point(69, 229)
        Me.btnNewDirectory.Name = "btnNewDirectory"
        Me.btnNewDirectory.Size = New System.Drawing.Size(330, 30)
        Me.btnNewDirectory.TabIndex = 12
        Me.btnNewDirectory.Text = "Create New Phone Directory"
        Me.btnNewDirectory.UseVisualStyleBackColor = True
        '
        'ContactsDirectories
        '
        Me.ContactsDirectories.FormattingEnabled = True
        Me.ContactsDirectories.Location = New System.Drawing.Point(69, 80)
        Me.ContactsDirectories.Name = "ContactsDirectories"
        Me.ContactsDirectories.Size = New System.Drawing.Size(330, 134)
        Me.ContactsDirectories.TabIndex = 23
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(69, 320)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(547, 150)
        Me.DataGridView1.TabIndex = 24
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(437, 170)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(179, 24)
        Me.Button1.TabIndex = 25
        Me.Button1.Text = "Clear Textbox"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dgvOutput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 496)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ContactsDirectories)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnAddListing)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtCurrentDirectory)
        Me.Controls.Add(Me.btnNewDirectory)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "dgvOutput"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Telephone/Mobile Directories"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnAddListing As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtNumber As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtCurrentDirectory As TextBox
    Friend WithEvents btnNewDirectory As Button
    Friend WithEvents ContactsDirectories As ListBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button1 As Button
End Class
