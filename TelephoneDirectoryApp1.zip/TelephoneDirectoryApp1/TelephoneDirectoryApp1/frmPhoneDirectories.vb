﻿Public Class dgvOutput

    Dim directories() As String = IO.File.ReadAllLines("Directories.txt")

    Private Sub frmPhoneDirectories_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each directory In directories
            ContactsDirectories.Items.Add(directory)
        Next
    End Sub

    Private Sub btnNewDirectory_Click(sender As Object, e As EventArgs) Handles btnNewDirectory.Click

        'create new directory file
        Dim filename = InputBox("Please Enter the Name of the New Directory ")

        'add new directory to the PhoneDirectories.txt and to the list box
        If Not directories.Contains(filename) Then
            IO.File.Create(filename)
            IO.File.AppendAllText("Directories.txt", filename + vbNewLine)
            directories = IO.File.ReadAllLines("Directories.txt")
            ContactsDirectories.Items.Clear()
            For Each directory In directories
                ContactsDirectories.Items.Add(directory)
            Next

        Else
            MessageBox.Show("Directory " + filename + " already exist!", "Duplicate Directory", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub ContactsDirectories_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ContactsDirectories.SelectedIndexChanged
        txtCurrentDirectory.Text = ContactsDirectories.SelectedItem.ToString()
        DisplayData(txtCurrentDirectory.Text)
    End Sub


    Private Sub DisplayData(selectedDirectory As String)

        Dim query = From dir In IO.File.ReadAllLines(selectedDirectory)
                    Let name As String = dir.Split(","c)(0)
                    Let phone As String = dir.Split(","c)(1)
                    Order By name
                    Select name, phone

        DataGridView1.DataSource = query.ToList
        DataGridView1.Columns(0).HeaderText = "Name"
        DataGridView1.Columns(1).HeaderText = "Telephone/Mobile Number"
    End Sub

    'add contact
    Private Sub btnAddListing_Click(sender As Object, e As EventArgs) Handles btnAddListing.Click
        Dim name As String = txtName.Text
        Dim phone As String = txtNumber.Text
        Dim selectedDirectory As String = txtCurrentDirectory.Text

        If name.Trim().Length > 0 And phone.Trim().Length > 0 And selectedDirectory.Trim().Length > 0 Then
            Dim sr As IO.StreamWriter = IO.File.AppendText(selectedDirectory)
            sr.WriteLine(name + "," + phone)
            sr.Close()
            DisplayData(selectedDirectory)
        Else
            MessageBox.Show("Select directory and enter Name and Phone to add", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    'delete contact
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim nameToDelete As String = txtName.Text
        Dim selectedDirectory As String = txtCurrentDirectory.Text
        Dim sr As IO.StreamWriter

        If nameToDelete.Trim().Length > 0 And selectedDirectory.Trim().Length > 0 Then
            Dim query = From data In IO.File.ReadAllLines(selectedDirectory)
                        Let name As String = data.Split(","c)(0)
                        Let phone As String = data.Split(","c)(1)
                        Where name <> nameToDelete
                        Let output As String = name + "," + phone
                        Select output

            sr = IO.File.CreateText(selectedDirectory)
            For i As Integer = 0 To query.Count() - 1
                sr.WriteLine(query(i))
            Next

            sr.Close()
            DisplayData(selectedDirectory)

        Else
            MessageBox.Show("Select a record to Delete", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)



        End If
    End Sub

    'DataGridView --- to view the name and number
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim row = DataGridView1.CurrentRow.Index
        txtName.Text = DataGridView1.Item(0, row).Value.ToString
        txtNumber.Text = DataGridView1.Item(1, row).Value.ToString
    End Sub

    'clear textbox
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtName.Text = ""
        txtNumber.Text = ""
        txtCurrentDirectory.Text = ""
    End Sub
End Class
